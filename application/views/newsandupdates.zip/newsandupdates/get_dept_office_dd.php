<?php
if($type_val == 'corporate'){
?>
<label class="col-sm-3 col-md-2 control-label">Department<span class="spanclass text-danger">*</span></label>
<div class="col-sm-9 col-md-10">
    <select required class="form-control" title="Department" name="department" id="department" onchange="get_action_office();">
        <option value="">Select an option</option>
        <?php
        foreach ($departments as $value):
//                                        if ($value['name'] != "Franchise" || ($value['name'] == "Franchise" && $staff_info['type'] != 3)):
            ?>
            <option value="<?= $value["id"]; ?>"><?= $value["name"]; ?></option>
            <?php
//                                        endif;
        endforeach;
        ?>
    </select>
    <div class="errorMessage text-danger"></div>
</div>
<?php
}elseif($type_val == 'franchisee'){
?>
<label class="col-sm-3 col-md-2 control-label">Office<span class="spanclass text-danger">*</span></label>
<div class="col-sm-9 col-md-10">
    <select required class="form-control" title="Department" name="office" id="department" onchange="get_action_office_for_news();">
        <option value="">Select an option</option>
        <?php
        foreach ($departments as $value):
//                                        if ($value['name'] != "Franchise" || ($value['name'] == "Franchise" && $staff_info['type'] != 3)):
            ?>
            <option value="<?= $value["id"]; ?>"><?= $value["name"]; ?></option>
            <?php
//                                        endif;
        endforeach;
        ?>
    </select>
    <div class="errorMessage text-danger"></div>
</div>
<?php
}
?>